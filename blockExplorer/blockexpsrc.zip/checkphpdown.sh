sudo netstat -plnt
