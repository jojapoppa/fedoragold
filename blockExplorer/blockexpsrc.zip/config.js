var api = 'http://127.0.0.1:30159';
var donationAddress = "";
var blockTargetInterval = 30;
var coinUnits = 100;
var symbol = 'fed';
var refreshDelay = 30000;
// pools stats by MainCoins
var networkStat = {
 "fed": [
//["z-pool.com", "http://z-pool.com:8117"],
//["eu.turtlepool.space", "http://eu.turtlepool.space:8117"]
 ]
};

var networkStat2 = {
    "fed": [
	[""]
 ]
};
