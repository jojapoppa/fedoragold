Block explorer for FedoraGold CryptoNote based cryptocurrency.

#### Installation

1) It takes data from daemon fedoragold_daemon. It should be accessible from the Internet. Run fedoragold_daemon with open port as follows:
```bash
./Fedoragold_daemon --enable-cors="*" --enable_blockexplorer --rpc-bind-ip=0.0.0.0 --rpc-bind-port=30159
```
2) Just upload to your website and change 'api' variable in config.js to point to your daemon.


A lot of this code is from the great Karbovanets/Karbowanec-Blockchain-Explorer & from Turtlecoin
