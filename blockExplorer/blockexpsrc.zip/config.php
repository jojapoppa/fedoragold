<?php
return array(
        'api' => 'http://127.0.0.1:30159',
        'blockTargetInterval' => 30,
        'coinUnits' => 100
);
