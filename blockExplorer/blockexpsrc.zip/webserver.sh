cd /home/ubuntu/explorer_files
sleep 6
#/usr/bin/php -S 0.0.0.0:80 -t /home/ubuntu/explorer_files &
