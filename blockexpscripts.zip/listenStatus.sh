sudo lsof -nP -iTCP -sTCP:LISTEN
