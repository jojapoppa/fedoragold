echo "fs.file-max=6569231"
echo "test with reboot and...  cat /proc/sys/fs/file-max"
echo "sudo vi /etc/sysctl.conf"
