tail -f fedoragold_daemon.log
