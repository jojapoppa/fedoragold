sudo systemctl restart apache2
