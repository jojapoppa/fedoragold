<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>
            <?php echo $_SERVER["HTTP_HOST"]; ?>
        </title>
<style type="text/css">
/*<![CDATA[*/
 body {
  text-align: center;
  color: #336699;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 48px;
  font-weight: bold;
}
 h2.c1 {
  color: #CC6600;
  font-size: 24px;
  font-weight: lighter;
}
 p.c2 {
  color: #CC6600;
  font-size: 13px;
  font-weight: lighter;
}
/*]]>*/
</style>
    </head>
    <body>
<?php include 'index.html'; ?>  


        <?php echo $_SERVER["HTTP_HOST"]; ?>
        <h2 class="c1">
            sito in costruzione
        </h2>
        <p class="c2">
            hosting su piattaforma <?php echo $_SERVER["SERVER_SOFTWARE"]; ?>
        </p>
    </body>
</html>
